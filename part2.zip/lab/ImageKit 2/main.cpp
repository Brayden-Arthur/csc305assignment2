#include "Canvas.h"
#include <math.h>

const GLfloat skypoints[] = {
    -300.0f,-300.0f,-300.0f,
   -300.0f,-300.0f, 300.0f,
   -300.0f, 300.0f, 300.0f,
   300.0f, 300.0f,-300.0f,
   -300.0f,-300.0f,-300.0f,
   -300.0f, 300.0f,-300.0f,
   300.0f,-300.0f, 300.0f,
   -300.0f,-300.0f,-300.0f,
   300.0f,-300.0f,-300.0f,
   300.0f, 300.0f,-300.0f,
   300.0f,-300.0f,-300.0f,
   -300.0f,-300.0f,-300.0f,
   -300.0f,-300.0f,-300.0f,
   -300.0f, 300.0f, 300.0f,
   -300.0f, 300.0f,-300.0f,
   300.0f,-300.0f, 300.0f,
   -300.0f,-300.0f, 300.0f,
   -300.0f,-300.0f,-300.0f,
   -300.0f, 300.0f, 300.0f,
   -300.0f,-300.0f, 300.0f,
   300.0f,-300.0f, 300.0f,
   300.0f, 300.0f, 300.0f,
   300.0f,-300.0f,-300.0f,
   300.0f, 300.0f,-300.0f,
   300.0f,-300.0f,-300.0f,
   300.0f, 300.0f, 300.0f,
   300.0f,-300.0f, 300.0f,
   300.0f, 300.0f, 300.0f,
   300.0f, 300.0f,-300.0f,
   -300.0f, 300.0f,-300.0f,
   300.0f, 300.0f, 300.0f,
   -300.0f, 300.0f,-300.0f,
   -300.0f, 300.0f, 300.0f,
   300.0f, 300.0f, 300.0f,
   -300.0f, 300.0f, 300.0f,
   300.0f,-300.0f, 300.0f
};

const GLfloat vpoint[] = {
    -0.3f,-0.3f,-0.3f,
   -0.3f,-0.3f, 0.3f,
   -0.3f, 0.3f, 0.3f,
   0.3f, 0.3f,-0.3f,
   -0.3f,-0.3f,-0.3f,
   -0.3f, 0.3f,-0.3f,
   0.3f,-0.3f, 0.3f,
   -0.3f,-0.3f,-0.3f,
   0.3f,-0.3f,-0.3f,
   0.3f, 0.3f,-0.3f,
   0.3f,-0.3f,-0.3f,
   -0.3f,-0.3f,-0.3f,
   -0.3f,-0.3f,-0.3f,
   -0.3f, 0.3f, 0.3f,
   -0.3f, 0.3f,-0.3f,
   0.3f,-0.3f, 0.3f,
   -0.3f,-0.3f, 0.3f,
   -0.3f,-0.3f,-0.3f,
   -0.3f, 0.3f, 0.3f,
   -0.3f,-0.3f, 0.3f,
   0.3f,-0.3f, 0.3f,
   0.3f, 0.3f, 0.3f,
   0.3f,-0.3f,-0.3f,
   0.3f, 0.3f,-0.3f,
   0.3f,-0.3f,-0.3f,
   0.3f, 0.3f, 0.3f,
   0.3f,-0.3f, 0.3f,
   0.3f, 0.3f, 0.3f,
   0.3f, 0.3f,-0.3f,
   -0.3f, 0.3f,-0.3f,
   0.3f, 0.3f, 0.3f,
   -0.3f, 0.3f,-0.3f,
   -0.3f, 0.3f, 0.3f,
   0.3f, 0.3f, 0.3f,
   -0.3f, 0.3f, 0.3f,
   0.3f,-0.3f, 0.3f
};

void createSphere(float radius){
    //const GLfloat spherepoints[800];
    int j = 0;
    int n = 0;
    //.866 is height of each tri.. better way?

    for(int i = 0; i < 100; i++){

        do{

            n--;
            j++;
        }while(j < n);

    }
}
const GLfloat colorArray[] = {
    0, 0, 0,   0, 0, 1,   0, 1, 1,   0, 1, 0,
    1, 0, 0,   1, 0, 1,   1, 1, 1,   1, 1, 0,
    0, 0, 0,   0, 0, 1,   1, 0, 1,   1, 0, 0,
    0, 1, 0,   0, 1, 1,   1, 1, 1,   1, 1, 0,
    0, 0, 0,   0, 1, 0,   1, 1, 0,   1, 0, 0,
    0, 0, 1,   0, 1, 1,   1, 1, 1,   1, 0, 1
};


const GLfloat vtexcoord[] = { 0.0f, 0.0f,
                              1.0f, 0.0f,
                              0.0f, 1.0f, //upper half of the square
                              1.0f, 0.0f,
                              1.0f, 1.0f,
                              0.0f, 1.0f }; //lower half of the square


const char * vshader_square = " \
        #version 330 core \n\
        in vec3 vpoint; \
        in vec3 skypoint; \
        in vec2 vtexcoord; \
        out vec2 uv; \
        out vec3 cpoint;\
        uniform float rotation; \
        \
        mat4 RotationMatrix(float rot){\
            mat3 R = mat3(1);\
            R[0][0] =  cos(rot);\
            R[0][2] =  sin(rot);\
            R[2][0] =  -sin(rot);\
            R[0][1] = -sin(rot);\
            R[1][0] = sin(rot);\
            R[1][1] = cos(rot);\
            return mat4(R);\
        }\
        mat4 ViewMatrix(){\
        return mat4(0);\
        }\
        void main() { \
            uv = vtexcoord; \
            gl_Position = RotationMatrix(rotation) * vec4(vpoint, 1); \
            cpoint = vpoint * vec3(sin(42), cos(42), tan(42));\
        } \
        ";

//texture(tex, uv_zoom).rgb * texture(tex, uv).a
const char * fshader_square = " \
        #version 330 core \n\
        in vec2 uv; \
        in vec3 cpoint;\
        out vec3 color; \
        uniform sampler2D tex;\
        uniform float texZoom; \
        void main() { \
        vec2 uv_centre = vec2(0.5, 0.5); \
        vec2 uv_zoom = texZoom * (uv - uv_centre) + uv_centre;\
        color = vec3(cpoint[1] + .2,cpoint[0] + .1,cpoint[2] + .25); }\
        ";

unsigned int width = 1000;
unsigned int height = 1000;

float Rotation = 0;
float RotatingSpeed = -0.01f;
float TexZoom = 1;
Canvas canvas;

//OpenGL context variables
GLuint programID = 0;
GLuint VertexArrayID = 0;
GLuint RotBindingID = 0;
GLuint TexZoomID = 0;

bool leftButtonPressed = false;
double lastYPosition = 0;

void InitializeGL()
{
    //Compile the shaders
    programID = compile_shaders(vshader_square, fshader_square);

    //depth buffer
    GLuint depthbuffer;
    glGenBuffers(1, &depthbuffer);
    glEnable(GL_DEPTH_TEST);
    glDepthRange(.9,3);

    //Generate Vertex Array and bind the vertex buffer data
    glGenVertexArrays(1, &VertexArrayID);
    glBindVertexArray(VertexArrayID);

    ///--- Bind the vertex position
    GLuint vertexbuffer;
    glGenBuffers(1, &vertexbuffer);
    /// The subsequent commands will affect the specified buffer
    glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer);
    /// Pass the vertex positions to OpenGL
    glBufferData(GL_ARRAY_BUFFER, sizeof(vpoint), vpoint, GL_STATIC_DRAW);

    ///--- find the binding point in the shader:
    /// "vpoint" in the vertex shader
    glUseProgram(programID);
    GLuint vpoint_id = glGetAttribLocation(programID, "vpoint");
    glEnableVertexAttribArray(vpoint_id);
    glVertexAttribPointer(vpoint_id,
                          3, //size per vertex (3 floats for cord)
                          GL_FLOAT,
                          false, //don't normalize
                          0, //stride = 0
                          0); //offset = 0

    /// --- Bind the texture coordinate
    GLuint texcoordbuffer;
    glGenBuffers(1, &texcoordbuffer);
    glBindBuffer(GL_ARRAY_BUFFER, texcoordbuffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vtexcoord), vtexcoord, GL_STATIC_DRAW);
    GLuint texcoordBindingPosition = glGetAttribLocation(programID, "vtexcoord");
    glEnableVertexAttribArray(texcoordBindingPosition);
    glVertexAttribPointer(texcoordBindingPosition, 2, GL_FLOAT,
        GL_FALSE, 0, (void *)0);

    /// --- Load the texture image
    Texture teximage = LoadPNGTexture("texture.png");

    /// --- Set openGL texture parameters
    GLuint texobject;
    glGenTextures(1, &texobject);
    glBindTexture(GL_TEXTURE_2D, texobject);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, teximage.width,
        teximage.height, 0, GL_RGBA, GL_UNSIGNED_BYTE,
        teximage.dataptr);

    /// --- Activate the loaded texture in channel 0
    GLuint tex_bindingpoint = glGetUniformLocation(programID, "tex");
    glUniform1i(tex_bindingpoint, 0 /*GL_TEXTURE0*/);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, texobject);

    //Find the binding point for the uniform variable
    //"rotation" in vertex shader
    RotBindingID = glGetUniformLocation(programID, "rotation");
    TexZoomID = glGetUniformLocation(programID, "texZoom");
}

void MouseMove(double x, double y)
{
    if (leftButtonPressed == true)
    {
        TexZoom += (y - lastYPosition) * 0.002f;
        if (TexZoom >= 1) TexZoom = 1;
        if (TexZoom < 0.001) TexZoom = 0.001;
    }
    lastYPosition = y;
}

void MouseButton(MouseButtons mouseButton, bool press)
{
    if (mouseButton == LeftButton)
    {
        if (press == true) leftButtonPressed = true;
        else leftButtonPressed = false;
    }
}

void KeyPress(char keychar)
{

}

void OnPaint()
{
    //Binding the openGL context
    glClear(GL_COLOR_BUFFER_BIT);
    glClear(GL_DEPTH_BUFFER_BIT);
    glUseProgram(programID);
    glBindVertexArray(VertexArrayID);
        //upload current rotation to GPU
        glUniform1f(RotBindingID, Rotation);
        glUniform1f(TexZoomID, TexZoom);
        glDrawArrays(GL_TRIANGLES, 0 /*buffer offset*/, 72 /*#vertices*/);
    //Clean up the openGL context for other drawings
    glUseProgram(0);
    glBindVertexArray(0);
}

void OnTimer()
{
    Rotation += RotatingSpeed;
}

int main(int, char **){
    //Link the call backs
    canvas.SetMouseMove(MouseMove);
    canvas.SetMouseButton(MouseButton);
    canvas.SetKeyPress(KeyPress);
    canvas.SetOnPaint(OnPaint);
    canvas.SetTimer(0.05, OnTimer);
    //Show Window
    canvas.Initialize(width, height, "Rotating Square Demo");
    //Do our initialization
    InitializeGL();
    canvas.Show();

    return 0;
}

#include "Canvas.h"
#include <math.h>

unsigned int width = 512;
unsigned int height = 512;
float prevx = 0;
float prevy = 0;
float xangle = 0;
float yangle = 0;
float Rotation = 0.00001;
float RotatingSpeed = 0.02;
Canvas canvas;
bool leftB = false;
bool rightB = false;
bool l = false;

float a[] = {-1,-1, -1, 1};//back face
float b[] = {-1, 1, -1, 1};
float c[] = {1, 1, -1, 1};
float d[] = {1, -1, -1, 1};
float e[] = {1, 1, 1, 1};//front face
float f[] = {1, -1, 1, 1};
float g[] = {-1,-1, 1, 1};
float h[] = {-1, 1, 1, 1};
float a1[4];
float b1[4];
float c1[4];
float d1[4];
float e1[4];
float f1[4];
float g1[4];
float h1[4];

float left = -1;
float right = 1;
float top = 1;
float bottom = -1;
float near = -2;
float far = -10;

float viewUp[3] = {0,1,0};
float cam[3] = {0,0,1};
float theta = 0;
float phi = 0;

//for view
float WVECTOR[3] = {0,0,0};
float UVECTOR[3] = {0,0,0};
float VVECTOR[3] = {0,0,0};
float UVWMATRIX[16];

void getW(float gaze[3]){
    float gLength = sqrt(pow(gaze[0] ,2) + pow(gaze[1] ,2) + pow(gaze[2] ,2));
    gaze[0] = -(gaze[0]/gLength);
    gaze[1] = -(gaze[1]/gLength);
    gaze[2] = -(gaze[2]/gLength);
}

void getU(float t[3], float gaze[3], float uVec[3]){
    float tLength = sqrt(pow(t[0] ,2) + pow(t[1] ,2) + pow(t[2] ,2));
    t[0] = t[0]/tLength;
    t[1] = t[1]/tLength;
    t[2] = t[2]/tLength;
    uVec[0] = t[1] * gaze[2] - t[2] * gaze[1];
    uVec[1] = t[2] * gaze[0] - t[0] * gaze[2];
    uVec[2] = t[0] * gaze[1] - t[1] * gaze[0];
    float uLength = sqrt(pow(uVec[0] ,2) + pow(uVec[1] ,2) + pow(uVec[2] ,2));
    uVec[0] = (uVec[0]/uLength);
    uVec[1] = (uVec[1]/uLength);
    uVec[2] = (uVec[2]/uLength);
}

void getV(float wVec[3], float uVec[3], float vVec[3]){
    vVec[0] = wVec[1] * uVec[2] - wVec[2] * uVec[1];
    vVec[1] = wVec[2] * uVec[0] - wVec[0] * uVec[2];
    vVec[2] = wVec[0] * uVec[1] - wVec[1] * uVec[0];
    float vLength = sqrt(pow(vVec[0] ,2) + pow(vVec[1] ,2) + pow(vVec[2] ,2));
    vVec[0] = (vVec[0]/vLength);
    vVec[1] = (vVec[1]/vLength);
    vVec[2] = (vVec[2]/vLength);//*/
}



void MouseMove(double x, double y)
{
    if(leftB){
        phi = theta = 0;
        theta = (x - prevx)*0.001;
        phi   = (y - prevy)*0.001;
        cam[0] = cam[0] * cos(theta) +  cam[2] * sin(theta);
        cam[2] = -cam[0] * sin(theta) + cam[2] * cos(theta);//x
        if(l){
        cam[1] = cam[1] * cos(phi) + cam[2] * -sin(phi);
        cam[2] = cam[1] * sin(phi) + cam[2] * cos(phi);//y*/
    }}
    if(rightB){
        phi = theta = 0;
        cam[2] = (prevy - y)*.01;
    }
    prevx = x;
    prevy = x;
}

void MouseButton(MouseButtons mouseButton, bool press)
{
    printf("bool=%d\n",l);
    if(mouseButton == LeftButton && press){
        leftB = true;
    }
    else leftB = false;
    if(mouseButton == RightButton && press){
        rightB = true;
    }
    else rightB = false;
}

void KeyPress(char keychar)
{
    if(keychar == 'L') l = !l;
}

void OnPaint()
{
}

void OnTimer()
{

    canvas.Clear();
    //multiply Morth * Mp * Mv

    float view1[3];


    //printf("WVEC0 = %f, WVEC1 = %f, WVEC2 = %f\n",WVECTOR[0],WVECTOR[1],WVECTOR[2]);

    float gLength = sqrt(pow(cam[0] ,2) + pow(cam[1] ,2) + pow(cam[2] ,2));

    WVECTOR[0] = -(cam[0]/gLength);
    WVECTOR[1] = -(cam[1]/gLength);
    WVECTOR[2] = -(cam[2]/gLength);

    view1[0] = viewUp[1] * WVECTOR[2] - viewUp[2] * WVECTOR[1];
    view1[1] = viewUp[2] * WVECTOR[0] - viewUp[0] * WVECTOR[2];
    view1[2] = viewUp[0] * WVECTOR[1] - viewUp[1] * WVECTOR[0];

    //WVECTOR[0] =


    //Mv
    getW(WVECTOR);
    getU(viewUp,WVECTOR,UVECTOR);
    getV(WVECTOR,UVECTOR,VVECTOR);
    /*
     *
     */
    UVWMATRIX[0] = UVECTOR[0];
    UVWMATRIX[1] = UVECTOR[1];
    UVWMATRIX[2] = UVECTOR[2];
    UVWMATRIX[3] = (-cam[0] * UVECTOR[0]) + (-cam[1] * UVECTOR[1]) + (-cam[2] * UVECTOR[2]);
    UVWMATRIX[4] = VVECTOR[0];
    UVWMATRIX[5] = VVECTOR[1];
    UVWMATRIX[6] = VVECTOR[2];
    UVWMATRIX[7] = (-cam[0] * VVECTOR[0]) + (-cam[1] * VVECTOR[1]) + (-cam[2] * VVECTOR[2]);
    UVWMATRIX[8] = WVECTOR[0];
    UVWMATRIX[9] = WVECTOR[1];
    UVWMATRIX[10] = WVECTOR[2];
    UVWMATRIX[11] = (-cam[0] * WVECTOR[0]) + (-cam[1] * WVECTOR[1]) + (-cam[2] * WVECTOR[2]);
    UVWMATRIX[12] = 0;
    UVWMATRIX[13] = 0;
    UVWMATRIX[14] = 0;
    UVWMATRIX[15] = 1;

    a1[0] = UVWMATRIX[0] * a[0] + UVWMATRIX[1] * a[1] + UVWMATRIX[2] * a[2] + UVWMATRIX[3] * a[3];
    a1[1] = UVWMATRIX[4] * a[0] + UVWMATRIX[5] * a[1] + UVWMATRIX[6] * a[2] + UVWMATRIX[7] * a[3];
    a1[2] = UVWMATRIX[8] * a[0] + UVWMATRIX[9] * a[1] + UVWMATRIX[10] * a[2] + UVWMATRIX[11] * a[3];
    a1[3] = UVWMATRIX[12] * a[0] + UVWMATRIX[13] * a[1] + UVWMATRIX[14] * a[2] + UVWMATRIX[15] * a[3];
    b1[0] = UVWMATRIX[0] * b[0] + UVWMATRIX[1] * b[1] + UVWMATRIX[2] * b[2] + UVWMATRIX[3] * b[3];
    b1[1] = UVWMATRIX[4] * b[0] + UVWMATRIX[5] * b[1] + UVWMATRIX[6] * b[2] + UVWMATRIX[7] * b[3];
    b1[2] = UVWMATRIX[8] * b[0] + UVWMATRIX[9] * b[1] + UVWMATRIX[10] * b[2] + UVWMATRIX[11] * b[3];
    b1[3] = UVWMATRIX[12] * b[0] + UVWMATRIX[13] * b[1] + UVWMATRIX[14] * b[2] + UVWMATRIX[15] * b[3];
    c1[0] = UVWMATRIX[0] * c[0] + UVWMATRIX[1] * c[1] + UVWMATRIX[2] * c[2] + UVWMATRIX[3] * c[3];
    c1[1] = UVWMATRIX[4] * c[0] + UVWMATRIX[5] * c[1] + UVWMATRIX[6] * c[2] + UVWMATRIX[7] * c[3];
    c1[2] = UVWMATRIX[8] * c[0] + UVWMATRIX[9] * c[1] + UVWMATRIX[10] * c[2] + UVWMATRIX[11] * c[3];
    c1[3] = UVWMATRIX[12] * c[0] + UVWMATRIX[13] * c[1] + UVWMATRIX[14] * c[2] + UVWMATRIX[15] * c[3];
    d1[0] = UVWMATRIX[0] * d[0] + UVWMATRIX[1] * d[1] + UVWMATRIX[2] * d[2] + UVWMATRIX[3] * d[3];
    d1[1] = UVWMATRIX[4] * d[0] + UVWMATRIX[5] * d[1] + UVWMATRIX[6] * d[2] + UVWMATRIX[7] * d[3];
    d1[2] = UVWMATRIX[8] * d[0] + UVWMATRIX[9] * d[1] + UVWMATRIX[10] * d[2] + UVWMATRIX[11] * d[3];
    d1[3] = UVWMATRIX[12] * d[0] + UVWMATRIX[13] * d[1] + UVWMATRIX[14] * d[2] + UVWMATRIX[15] * d[3];
    e1[0] = UVWMATRIX[0] * e[0] + UVWMATRIX[1] * e[1] + UVWMATRIX[2] * e[2] + UVWMATRIX[3] * e[3];
    e1[1] = UVWMATRIX[4] * e[0] + UVWMATRIX[5] * e[1] + UVWMATRIX[6] * e[2] + UVWMATRIX[7] * e[3];
    e1[2] = UVWMATRIX[8] * e[0] + UVWMATRIX[9] * e[1] + UVWMATRIX[10] * e[2] + UVWMATRIX[11] * e[3];
    e1[3] = UVWMATRIX[12] * e[0] + UVWMATRIX[13] * e[1] + UVWMATRIX[14] * e[2] + UVWMATRIX[15] * e[3];
    f1[0] = UVWMATRIX[0] * f[0] + UVWMATRIX[1] * f[1] + UVWMATRIX[2] * f[2] + UVWMATRIX[3] * f[3];
    f1[1] = UVWMATRIX[4] * f[0] + UVWMATRIX[5] * f[1] + UVWMATRIX[6] * f[2] + UVWMATRIX[7] * f[3];
    f1[2] = UVWMATRIX[8] * f[0] + UVWMATRIX[9] * f[1] + UVWMATRIX[10] * f[2] + UVWMATRIX[11] * f[3];
    f1[3] = UVWMATRIX[12] * f[0] + UVWMATRIX[13] * f[1] + UVWMATRIX[14] * f[2] + UVWMATRIX[15] * f[3];
    g1[0] = UVWMATRIX[0] * g[0] + UVWMATRIX[1] * g[1] + UVWMATRIX[2] * g[2] + UVWMATRIX[3] * g[3];
    g1[1] = UVWMATRIX[4] * g[0] + UVWMATRIX[5] * g[1] + UVWMATRIX[6] * g[2] + UVWMATRIX[7] * g[3];
    g1[2] = UVWMATRIX[8] * g[0] + UVWMATRIX[9] * g[1] + UVWMATRIX[10] * g[2] + UVWMATRIX[11] * g[3];
    g1[3] = UVWMATRIX[12] * g[0] + UVWMATRIX[13] * g[1] + UVWMATRIX[14] * g[2] + UVWMATRIX[15] * g[3];
    h1[0] = UVWMATRIX[0] * h[0] + UVWMATRIX[1] * h[1] + UVWMATRIX[2] * h[2] + UVWMATRIX[3] * h[3];
    h1[1] = UVWMATRIX[4] * h[0] + UVWMATRIX[5] * h[1] + UVWMATRIX[6] * h[2] + UVWMATRIX[7] * h[3];
    h1[2] = UVWMATRIX[8] * h[0] + UVWMATRIX[9] * h[1] + UVWMATRIX[10] * h[2] + UVWMATRIX[11] * h[3];
    h1[3] = UVWMATRIX[12] * h[0] + UVWMATRIX[13] * h[1] + UVWMATRIX[14] * h[2] + UVWMATRIX[15] * h[3];

    //Mp
        float Mp[16] = {
            near/right, 0,           0,              0,
            0, near/top,           0,              0,
            0,    0,  -(near + far)/(far - near),  -(2 * far * near)/(far - near),
            0,    0,           -1,       0
        };
        a1[0] = Mp[0] * a1[0] + Mp[1] * a1[1] + Mp[2] * a1[2] + Mp[3] * a1[3];
        a1[1] = Mp[4] * a1[0] + Mp[5] * a1[1] + Mp[6] * a1[2] + Mp[7] * a1[3];
        a1[2] = Mp[8] * a1[0] + Mp[9] * a1[1] + Mp[10] * a1[2] + Mp[11] * a1[3];
        a1[3] = Mp[12] * a1[0] + Mp[13] * a1[1] + Mp[14] * a1[2] + Mp[15] * a1[3];
        b1[0] = Mp[0] * b1[0] + Mp[1] * b1[1] + Mp[2] * b1[2] + Mp[3] * b1[3];
        b1[1] = Mp[4] * b1[0] + Mp[5] * b1[1] + Mp[6] * b1[2] + Mp[7] * b1[3];
        b1[2] = Mp[8] * b1[0] + Mp[9] * b1[1] + Mp[10] * b1[2] + Mp[11] * b1[3];
        b1[3] = Mp[12] * b1[0] + Mp[13] * b1[1] + Mp[14] * b1[2] + Mp[15] * b1[3];
        c1[0] = Mp[0] * c1[0] + Mp[1] * c1[1] + Mp[2] * c1[2] + Mp[3] * c1[3];
        c1[1] = Mp[4] * c1[0] + Mp[5] * c1[1] + Mp[6] * c1[2] + Mp[7] * c1[3];
        c1[2] = Mp[8] * c1[0] + Mp[9] * c1[1] + Mp[10] * c1[2] + Mp[11] * c1[3];
        c1[3] = Mp[12] * c1[0] + Mp[13] * c1[1] + Mp[14] * c1[2] + Mp[15] * c1[3];
        d1[0] = Mp[0] * d1[0] + Mp[1] * d1[1] + Mp[2] * d1[2] + Mp[3] * d1[3];
        d1[1] = Mp[4] * d1[0] + Mp[5] * d1[1] + Mp[6] * d1[2] + Mp[7] * d1[3];
        d1[2] = Mp[8] * d1[0] + Mp[9] * d1[1] + Mp[10] * d1[2] + Mp[11] * d1[3];
        d1[3] = Mp[12] * d1[0] + Mp[13] * d1[1] + Mp[14] * d1[2] + Mp[15] * d1[3];
        e1[0] = Mp[0] * e1[0] + Mp[1] * e1[1] + Mp[2] * e1[2] + Mp[3] * e1[3];
        e1[1] = Mp[4] * e1[0] + Mp[5] * e1[1] + Mp[6] * e1[2] + Mp[7] * e1[3];
        e1[2] = Mp[8] * e1[0] + Mp[9] * e1[1] + Mp[10] * e1[2] + Mp[11] * e1[3];
        e1[3] = Mp[12] * e1[0] + Mp[13] * e1[1] + Mp[14] * e1[2] + Mp[15] * e1[3];
        f1[0] = Mp[0] * f1[0] + Mp[1] * f1[1] + Mp[2] * f1[2] + Mp[3] * f1[3];
        f1[1] = Mp[4] * f1[0] + Mp[5] * f1[1] + Mp[6] * f1[2] + Mp[7] * f1[3];
        f1[2] = Mp[8] * f1[0] + Mp[9] * f1[1] + Mp[10] * f1[2] + Mp[11] * f1[3];
        f1[3] = Mp[12] * f1[0] + Mp[13] * f1[1] + Mp[14] * f1[2] + Mp[15] * f1[3];
        g1[0] = Mp[0] * g1[0] + Mp[1] * g1[1] + Mp[2] * g1[2] + Mp[3] * g1[3];
        g1[1] = Mp[4] * g1[0] + Mp[5] * g1[1] + Mp[6] * g1[2] + Mp[7] * g1[3];
        g1[2] = Mp[8] * g1[0] + Mp[9] * g1[1] + Mp[10] * g1[2] + Mp[11] * g1[3];
        g1[3] = Mp[12] * g1[0] + Mp[13] * g1[1] + Mp[14] * g1[2] + Mp[15] * g1[3];
        h1[0] = Mp[0] * h1[0] + Mp[1] * h1[1] + Mp[2] * h1[2] + Mp[3] * h1[3];
        h1[1] = Mp[4] * h1[0] + Mp[5] * h1[1] + Mp[6] * h1[2] + Mp[7] * h1[3];
        h1[2] = Mp[8] * h1[0] + Mp[9] * h1[1] + Mp[10] * h1[2] + Mp[11] * h1[3];
        h1[3] = Mp[12] * h1[0] + Mp[13] * h1[1] + Mp[14] * h1[2] + Mp[15] * h1[3];

    //Mo
    float Mo[16] = {
        1,         0,         0,         0,
        0,         1,         0,         0,
        0,         0,         2/(near-far),   -((near + far)/(near-far)),
        0,         0,         0,         1
    };

    a1[0] = Mo[0] * a1[0] + Mo[1] * a1[1] + Mo[2] * a1[2] + Mo[3] * a1[3];
    a1[1] = Mo[4] * a1[0] + Mo[5] * a1[1] + Mo[6] * a1[2] + Mo[7] * a1[3];
    a1[2] = Mo[8] * a1[0] + Mo[9] * a1[1] + Mo[10] * a1[2] + Mo[11] * a1[3];
    a1[3] = Mo[12] * a1[0] + Mo[13] * a1[1] + Mo[14] * a1[2] + Mo[15] * a1[3];
    b1[0] = Mo[0] * b1[0] + Mo[1] * b1[1] + Mo[2] * b1[2] + Mo[3] * b1[3];
    b1[1] = Mo[4] * b1[0] + Mo[5] * b1[1] + Mo[6] * b1[2] + Mo[7] * b1[3];
    b1[2] = Mo[8] * b1[0] + Mo[9] * b1[1] + Mo[10] * b1[2] + Mo[11] * b1[3];
    b1[3] = Mo[12] * b1[0] + Mo[13] * b1[1] + Mo[14] * b1[2] + Mo[15] * b1[3];
    c1[0] = Mo[0] * c1[0] + Mo[1] * c1[1] + Mo[2] * c1[2] + Mo[3] * c1[3];
    c1[1] = Mo[4] * c1[0] + Mo[5] * c1[1] + Mo[6] * c1[2] + Mo[7] * c1[3];
    c1[2] = Mo[8] * c1[0] + Mo[9] * c1[1] + Mo[10] * c1[2] + Mo[11] * c1[3];
    c1[3] = Mo[12] * c1[0] + Mo[13] * c1[1] + Mo[14] * c1[2] + Mo[15] * c1[3];
    d1[0] = Mo[0] * d1[0] + Mo[1] * d1[1] + Mo[2] * d1[2] + Mo[3] * d1[3];
    d1[1] = Mo[4] * d1[0] + Mo[5] * d1[1] + Mo[6] * d1[2] + Mo[7] * d1[3];
    d1[2] = Mo[8] * d1[0] + Mo[9] * d1[1] + Mo[10] * d1[2] + Mo[11] * d1[3];
    d1[3] = Mo[12] * d1[0] + Mo[13] * d1[1] + Mo[14] * d1[2] + Mo[15] * d1[3];
    e1[0] = Mo[0] * e1[0] + Mo[1] * e1[1] + Mo[2] * e1[2] + Mo[3] * e1[3];
    e1[1] = Mo[4] * e1[0] + Mo[5] * e1[1] + Mo[6] * e1[2] + Mo[7] * e1[3];
    e1[2] = Mo[8] * e1[0] + Mo[9] * e1[1] + Mo[10] * e1[2] + Mo[11] * e1[3];
    e1[3] = Mo[12] * e1[0] + Mo[13] * e1[1] + Mo[14] * e1[2] + Mo[15] * e1[3];
    f1[0] = Mo[0] * f1[0] + Mo[1] * f1[1] + Mo[2] * f1[2] + Mo[3] * f1[3];
    f1[1] = Mo[4] * f1[0] + Mo[5] * f1[1] + Mo[6] * f1[2] + Mo[7] * f1[3];
    f1[2] = Mo[8] * f1[0] + Mo[9] * f1[1] + Mo[10] * f1[2] + Mo[11] * f1[3];
    f1[3] = Mo[12] * f1[0] + Mo[13] * f1[1] + Mo[14] * f1[2] + Mo[15] * f1[3];
    g1[0] = Mo[0] * g1[0] + Mo[1] * g1[1] + Mo[2] * g1[2] + Mo[3] * g1[3];
    g1[1] = Mo[4] * g1[0] + Mo[5] * g1[1] + Mo[6] * g1[2] + Mo[7] * g1[3];
    g1[2] = Mo[8] * g1[0] + Mo[9] * g1[1] + Mo[10] * g1[2] + Mo[11] * g1[3];
    g1[3] = Mo[12] * g1[0] + Mo[13] * g1[1] + Mo[14] * g1[2] + Mo[15] * g1[3];
    h1[0] = Mo[0] * h1[0] + Mo[1] * h1[1] + Mo[2] * h1[2] + Mo[3] * h1[3];
    h1[1] = Mo[4] * h1[0] + Mo[5] * h1[1] + Mo[6] * h1[2] + Mo[7] * h1[3];
    h1[2] = Mo[8] * h1[0] + Mo[9] * h1[1] + Mo[10] * h1[2] + Mo[11] * h1[3];
    h1[3] = Mo[12] * h1[0] + Mo[13] * h1[1] + Mo[14] * h1[2] + Mo[15] * h1[3];



     //normalized homogenous coordinates
    a1[0] = a1[0]/a1[3];
    a1[1] = a1[1]/a1[3];
    a1[2] = a1[2]/a1[3];
    a1[3] = 1;
    b1[0] = b1[0]/b1[3];
    b1[1] = b1[1]/b1[3];
    b1[2] = b1[2]/b1[3];
    b1[3] = 1;
    c1[0] = c1[0]/c1[3];
    c1[1] = c1[1]/c1[3];
    c1[2] = c1[2]/c1[3];
    c1[3] = 1;
    d1[0] = d1[0]/d1[3];
    d1[1] = d1[1]/d1[3];
    d1[2] = d1[2]/d1[3];
    d1[3] = 1;
    e1[0] = e1[0]/e1[3];
    e1[1] = e1[1]/e1[3];
    e1[2] = e1[2]/e1[3];
    e1[3] = 1;
    f1[0] = f1[0]/f1[3];
    f1[1] = f1[1]/f1[3];
    f1[2] = f1[2]/f1[3];
    f1[3] = 1;
    g1[0] = g1[0]/g1[3];
    g1[1] = g1[1]/g1[3];
    g1[2] = g1[2]/g1[3];
    g1[3] = 1;
    h1[0] = h1[0]/h1[3];
    h1[1] = h1[1]/h1[3];
    h1[2] = h1[2]/h1[3];
    h1[3] = 1;


    //square 1
    canvas.AddLine(a1[0],a1[1],b1[0],b1[1]);
    canvas.AddLine(b1[0],b1[1],c1[0],c1[1]);
    canvas.AddLine(c1[0],c1[1],d1[0],d1[1]);
    canvas.AddLine(d1[0],d1[1],a1[0],a1[1]);
    //square 2
    canvas.AddLine(e1[0],e1[1],f1[0],f1[1]);//left up
    canvas.AddLine(f1[0],f1[1],g1[0],g1[1]);//right up
    canvas.AddLine(g1[0],g1[1],h1[0],h1[1]);//up across
    canvas.AddLine(h1[0],h1[1],e1[0],e1[1]);//down across
    //diagonals
    canvas.AddLine(g1[0],g1[1],a1[0],a1[1]);
    canvas.AddLine(h1[0],h1[1],b1[0],b1[1]);
    canvas.AddLine(e1[0],e1[1],c1[0],c1[1]);
    canvas.AddLine(f1[0],f1[1],d1[0],d1[1]);
}

int main(int, char **){
    //Link the call backs
    canvas.SetMouseMove(MouseMove);
    canvas.SetMouseButton(MouseButton);
    canvas.SetKeyPress(KeyPress);
    canvas.SetOnPaint(OnPaint);
    canvas.SetTimer(.05, OnTimer);
    //Show Window
    canvas.Initialize(width, height, "LAIHGEWBGJKHWEGLIUGKWJN");
    //Do our initialization

    //square 1
    canvas.AddLine(a[0],a[1],b[0],b[1]);
    canvas.AddLine(b[0],b[1],c[0],c[1]);
    canvas.AddLine(c[0],c[1],d[0],d[1]);
    canvas.AddLine(d[0],d[1],a[0],a[1]);
    //square 2
    canvas.AddLine(e[0],e[1],f[0],f[1]);//left up
    canvas.AddLine(f[0],f[1],g[0],g[1]);//right up
    canvas.AddLine(g[0],g[1],h[0],h[1]);//up across
    canvas.AddLine(h[0],h[1],e[0],e[1]);//down across
    //diagonals
    canvas.AddLine(g[0],g[1],a[0],a[1]);
    canvas.AddLine(h[0],h[1],b[0],b[1]);
    canvas.AddLine(e[0],e[1],c[0],c[1]);
    canvas.AddLine(f[0],f[1],d[0],d[1]);
    canvas.Show();

    return 0;
}


/*
 *
 *     //Mp
    float Mp[16] = {
        1, 0,           0,              0,
        0, 1,           0,              0,
        0,    0,  (near + far)/near,  -far,
        0,    0,           1/near,       0
    };

    a[0] = Mp[0] * a[0] + Mp[1] * a[1] + Mp[2] * a[2] + Mp[3] * a[3];
    a[1] = Mp[4] * a[0] + Mp[5] * a[1] + Mp[6] * a[2] + Mp[7] * a[3];
    a[2] = Mp[8] * a[0] + Mp[9] * a[1] + Mp[10] * a[2] + Mp[11] * a[3];
    printf("W at Mp is %f = %f * %f + %f * %f + %f * %f + %f * %f\n",a[3],Mp[12], a[0], Mp[13], a[1], Mp[14], a[2], Mp[15], a[3]);
    a[3] = Mp[12] * a[0] + Mp[13] * a[1] + Mp[14] * a[2] + Mp[15] * a[3];
    printf("W at Mp is %f = %f * %f + %f * %f + %f * %f + %f * %f\n",a[3],Mp[12], a[0], Mp[13], a[1], Mp[14], a[2], Mp[15], a[3]);
    b[0] = Mp[0] * b[0] + Mp[1] * b[1] + Mp[2] * b[2] + Mp[3] * b[3];
    b[1] = Mp[4] * b[0] + Mp[5] * b[1] + Mp[6] * b[2] + Mp[7] * b[3];
    b[2] = Mp[8] * b[0] + Mp[9] * b[1] + Mp[10] * b[2] + Mp[11] * b[3];
    b[3] = Mp[12] * b[0] + Mp[13] * b[1] + Mp[14] * b[2] + Mp[15] * b[3];
    c[0] = Mp[0] * c[0] + Mp[1] * c[1] + Mp[2] * c[2] + Mp[3] * c[3];
    c[1] = Mp[4] * c[0] + Mp[5] * c[1] + Mp[6] * c[2] + Mp[7] * c[3];
    c[2] = Mp[8] * c[0] + Mp[9] * c[1] + Mp[10] * c[2] + Mp[11] * c[3];
    c[3] = Mp[12] * c[0] + Mp[13] * c[1] + Mp[14] * c[2] + Mp[15] * c[3];
    d[0] = Mp[0] * d[0] + Mp[1] * d[1] + Mp[2] * d[2] + Mp[3] * d[3];
    d[1] = Mp[4] * d[0] + Mp[5] * d[1] + Mp[6] * d[2] + Mp[7] * d[3];
    d[2] = Mp[8] * d[0] + Mp[9] * d[1] + Mp[10] * d[2] + Mp[11] * d[3];
    d[3] = Mp[12] * d[0] + Mp[13] * d[1] + Mp[14] * d[2] + Mp[15] * d[3];
    e[0] = Mp[0] * e[0] + Mp[1] * e[1] + Mp[2] * e[2] + Mp[3] * e[3];
    e[1] = Mp[4] * e[0] + Mp[5] * e[1] + Mp[6] * e[2] + Mp[7] * e[3];
    e[2] = Mp[8] * e[0] + Mp[9] * e[1] + Mp[10] * e[2] + Mp[11] * e[3];
    e[3] = Mp[12] * e[0] + Mp[13] * e[1] + Mp[14] * e[2] + Mp[15] * e[3];
    f[0] = Mp[0] * f[0] + Mp[1] * f[1] + Mp[2] * f[2] + Mp[3] * f[3];
    f[1] = Mp[4] * f[0] + Mp[5] * f[1] + Mp[6] * f[2] + Mp[7] * f[3];
    f[2] = Mp[8] * f[0] + Mp[9] * f[1] + Mp[10] * f[2] + Mp[11] * f[3];
    f[3] = Mp[12] * f[0] + Mp[13] * f[1] + Mp[14] * f[2] + Mp[15] * f[3];
    g[0] = Mp[0] * g[0] + Mp[1] * g[1] + Mp[2] * g[2] + Mp[3] * g[3];
    g[1] = Mp[4] * g[0] + Mp[5] * g[1] + Mp[6] * g[2] + Mp[7] * g[3];
    g[2] = Mp[8] * g[0] + Mp[9] * g[1] + Mp[10] * g[2] + Mp[11] * g[3];
    g[3] = Mp[12] * g[0] + Mp[13] * g[1] + Mp[14] * g[2] + Mp[15] * g[3];
    h[0] = Mp[0] * h[0] + Mp[1] * h[1] + Mp[2] * h[2] + Mp[3] * h[3];
    h[1] = Mp[4] * h[0] + Mp[5] * h[1] + Mp[6] * h[2] + Mp[7] * h[3];
    h[2] = Mp[8] * h[0] + Mp[9] * h[1] + Mp[10] * h[2] + Mp[11] * h[3];
    h[3] = Mp[12] * h[0] + Mp[13] * h[1] + Mp[14] * h[2] + Mp[15] * h[3];


    //rotations
    if(xangle > 0 && leftB){
        viewUp[1] = viewUp[1] * cos(xangle) - viewUp[2] * sin(xangle);
        viewUp[2] = viewUp[1] * sin(xangle) + viewUp[2] * cos(xangle);

        xangle = 0;
    }
    if(yangle > 0){

        yangle = 0;
    }



*/
